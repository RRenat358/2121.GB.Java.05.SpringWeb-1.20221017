package ru.gb.api;

import lombok.Value;

@Value
public class AuthResponse {

    String token;

}
